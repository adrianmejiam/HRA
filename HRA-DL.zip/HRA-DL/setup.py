# -*- coding: utf-8 -*-

from distutils.core import setup 
import py2exe 
 
setup(name="HRA-DL", 
 version="1.0", 
 description="Highresaudio_DL", 
 author="adrianmejiam", 
 author_email="adrianmexhd1@gmail.com", 
 url="url del proyecto", 
 license="tipo de licencia", 
 scripts=["HRA.py, 
 console=["HRA.py, 
 options={"py2exe": {"bundle_files": 1}}, 
 zipfile=None,
)